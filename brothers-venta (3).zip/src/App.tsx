import React, { useState, useEffect, useMemo } from 'react';
import JSZip from 'jszip';
import {
  ShoppingBag,
  Home as HomeIcon,
  ShoppingCart,
  Receipt,
  ClipboardList,
  Calculator,
  RotateCcw,
  Download,
  CheckCircle2,
  Plus,
  Trash2,
  X,
  Search,
  AlertCircle,
  TrendingUp,
  Clock,
  ArrowRight,
  Filter,
  ShieldCheck,
  FileDown,
  FileUp,
  Banknote,
  Building2,
  User,
  Check,
  FileText,
  Send,
  ChevronDown,
  ChevronUp,
  Calendar,
  CalendarDays,
  Hash
} from 'lucide-react';
import { Product, CartItem, ActiveSale, CompletedSale, ActivityLog, PaymentMethod, SalesReport, SalesReportProduct } from './types.ts';
import {
  PACKAGE_JSON,
  CAPACITOR_CONFIG,
  INDEX_HTML,
  VITE_CONFIG,
  TSCONFIG_JSON,
  SRC_INDEX_CSS,
  SRC_MAIN_TSX,
  SRC_TYPES_TS,
  SRC_PROJECT_FILES_TS,
  WORKFLOW_YML,
  getSrcAppTsx
} from './projectFiles.ts';

const STORAGE_KEY_PRODUCTS = 'brothers_venta_products_v1';
const STORAGE_KEY_ACTIVE_SALES = 'brothers_venta_active_sales_v1';
const STORAGE_KEY_COMPLETED_SALES = 'brothers_venta_completed_sales_v1';
const STORAGE_KEY_LOGS = 'brothers_venta_logs_v1';
const STORAGE_KEY_ORDER_COUNTER = 'brothers_venta_order_counter_v1';
const STORAGE_KEY_REPORTS = 'brothers_venta_reports_v1';
const STORAGE_KEY_REPORT_COUNTER = 'brothers_venta_report_counter_v1';

// 3 Productos de muestra iniciales (con las mismas características de Almacén)
const DEFAULT_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Aceite Vegetal 1L',
    buyPrice: 2.50,
    sellPrice: 3.80,
    stock: 24,
    category: 'Abarrotes',
  },
  {
    id: 'prod-2',
    name: 'Refresco Cola 2L',
    buyPrice: 1.20,
    sellPrice: 2.00,
    stock: 35,
    category: 'Bebidas',
  },
  {
    id: 'prod-3',
    name: 'Detergente en Polvo 1kg',
    buyPrice: 1.80,
    sellPrice: 2.90,
    stock: 18,
    category: 'Limpieza',
  },
];

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<number>(0);

  // 1. Catálogo de productos
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PRODUCTS);
      return saved ? JSON.parse(saved) : DEFAULT_PRODUCTS;
    } catch {
      return DEFAULT_PRODUCTS;
    }
  });

  // 2. Ventas en proceso en el Carrito
  const [activeSales, setActiveSales] = useState<ActiveSale[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACTIVE_SALES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // 3. Ventas completadas
  const [completedSales, setCompletedSales] = useState<CompletedSale[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_COMPLETED_SALES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // 4. Auditoría / Notificaciones
  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_LOGS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Contador de órdenes
  const [orderCounter, setOrderCounter] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ORDER_COUNTER);
      return saved ? parseInt(saved, 10) : 1;
    } catch {
      return 1;
    }
  });

  // Registro de Informes de Ventas
  const [reports, setReports] = useState<SalesReport[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REPORTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Contador correlativo de informes
  const [reportCounter, setReportCounter] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REPORT_COUNTER);
      return saved ? parseInt(saved, 10) : 1;
    } catch {
      return 1;
    }
  });

  // Guardado automático local (100% offline)
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ACTIVE_SALES, JSON.stringify(activeSales));
  }, [activeSales]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_COMPLETED_SALES, JSON.stringify(completedSales));
  }, [completedSales]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ORDER_COUNTER, orderCounter.toString());
  }, [orderCounter]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_REPORTS, JSON.stringify(reports));
  }, [reports]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_REPORT_COUNTER, reportCounter.toString());
  }, [reportCounter]);

  // Splash screen de 3 segundos
  useEffect(() => {
    if (!showSplash) return;
    setProgress(0);
    const totalDuration = 3000;
    const intervalTime = 50;
    const increment = 100 / (totalDuration / intervalTime);

    const progressTimer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(progressTimer);
          return 100;
        }
        return next;
      });
    }, intervalTime);

    const splashTimeout = setTimeout(() => {
      setShowSplash(false);
    }, totalDuration);

    return () => {
      clearInterval(progressTimer);
      clearTimeout(splashTimeout);
    };
  }, [showSplash]);

  const addLog = (
    type: ActivityLog['type'],
    title: string,
    description: string,
    details?: ActivityLog['details']
  ) => {
    const newLog: ActivityLog = {
      id: Date.now().toString() + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString(),
      type,
      title,
      description,
      details,
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // ----------------- ESTADOS MODALES: HOME / PRODUCTOS -----------------
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todas');

  // Modal: Agregar un producto individual al carrito
  const [productToAdd, setProductToAdd] = useState<Product | null>(null);
  const [addQuantity, setAddQuantity] = useState<number>(1);
  const [targetSaleMode, setTargetSaleMode] = useState<'new' | string>('new'); // 'new' o ID de venta en proceso
  const [targetCustomerName, setTargetCustomerName] = useState('');
  const [targetPaymentMethod, setTargetPaymentMethod] = useState<PaymentMethod>('efectivo');

  // Modal: Nueva Venta desde botón flotante de Home
  const [isFloatingSaleModalOpen, setIsFloatingSaleModalOpen] = useState(false);
  const [floatingCustomerName, setFloatingCustomerName] = useState('');
  const [floatingPaymentMethod, setFloatingPaymentMethod] = useState<PaymentMethod>('efectivo');
  const [floatingRows, setFloatingRows] = useState<{ productId: string; quantity: number }[]>([]);
  const [floatingError, setFloatingError] = useState('');

  // ----------------- ESTADOS MODALES: CARRITO -----------------
  const [cancellingSale, setCancellingSale] = useState<ActiveSale | null>(null);
  const [finishingSale, setFinishingSale] = useState<ActiveSale | null>(null);

  // ----------------- ESTADOS: INFORME DE VENTAS -----------------
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportDaysRange, setReportDaysRange] = useState<number | 'all'>('all');
  const [customDaysInput, setCustomDaysInput] = useState<string>('');
  const [reportFeedback, setReportFeedback] = useState<string | null>(null);
  const [isWaitingImplementationOpen, setIsWaitingImplementationOpen] = useState(false);
  const [expandedReportId, setExpandedReportId] = useState<string | null>(null);
  const [reportToDelete, setReportToDelete] = useState<SalesReport | null>(null);

  // ----------------- ESTADOS MODALES: CUENTAS -----------------
  const [isCalculateModalOpen, setIsCalculateModalOpen] = useState(false);
  const [calcPeriod, setCalcPeriod] = useState<'today' | '7days' | '30days' | 'all'>('today');
  const [calcPaymentFilter, setCalcPaymentFilter] = useState<'all' | 'efectivo' | 'transferencia'>('all');

  // ----------------- ESTADOS: BACKUP Y ZIP -----------------
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [backupMessage, setBackupMessage] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Categorías presentes en los productos
  const availableCategories = useMemo(() => {
    const cats = new Set<string>();
    products.forEach((p) => {
      if (p.category) cats.add(p.category);
    });
    return ['Todas', ...Array.from(cats)];
  }, [products]);

  // Productos filtrados en Home
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCat = selectedCategory === 'Todas' || p.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [products, searchTerm, selectedCategory]);

  // ----------------- MANEJADORES: AGREGAR PRODUCTO AL CARRITO -----------------
  const handleOpenAddProductModal = (prod: Product) => {
    setProductToAdd(prod);
    setAddQuantity(1);
    // Si hay ventas en proceso, por defecto seleccionamos la primera o 'new'
    if (activeSales.length > 0) {
      setTargetSaleMode(activeSales[0].id);
    } else {
      setTargetSaleMode('new');
    }
    setTargetCustomerName('');
    setTargetPaymentMethod('efectivo');
  };

  const handleConfirmAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productToAdd) return;

    const qty = Math.max(1, addQuantity);
    if (qty > productToAdd.stock) {
      alert(`Stock insuficiente. Solo quedan ${productToAdd.stock} unidades disponibles.`);
      return;
    }

    const itemSubtotal = productToAdd.sellPrice * qty;
    const itemCost = productToAdd.buyPrice * qty;

    const cartItem: CartItem = {
      productId: productToAdd.id,
      productName: productToAdd.name,
      buyPrice: productToAdd.buyPrice,
      sellPrice: productToAdd.sellPrice,
      quantity: qty,
      subtotal: itemSubtotal,
    };

    if (targetSaleMode === 'new' || activeSales.length === 0) {
      // Crear nueva venta en el carrito
      const currentOrder = orderCounter;
      setOrderCounter((prev) => prev + 1);

      const newSale: ActiveSale = {
        id: 'sale-' + Date.now().toString(),
        orderNumber: currentOrder,
        customerName: targetCustomerName.trim() || undefined,
        paymentMethod: targetPaymentMethod,
        items: [cartItem],
        totalAmount: itemSubtotal,
        totalCost: itemCost,
        createdAt: new Date().toISOString(),
      };

      setActiveSales((prev) => [newSale, ...prev]);

      addLog(
        'item_added',
        `Nueva Venta #${currentOrder} iniciada`,
        `Se agregó ${qty}x "${productToAdd.name}" a la nueva venta (${targetPaymentMethod === 'transferencia' ? 'Transferencia al Jefe' : 'Efectivo'}).`,
        {
          orderNumber: currentOrder,
          customerName: targetCustomerName.trim() || 'General',
          paymentMethod: targetPaymentMethod,
          totalAmount: itemSubtotal,
        }
      );
    } else {
      // Agregar a una venta en proceso existente
      const existingSale = activeSales.find((s) => s.id === targetSaleMode);
      if (!existingSale) return;

      setActiveSales((prev) =>
        prev.map((sale) => {
          if (sale.id !== targetSaleMode) return sale;

          // Si el producto ya está en la venta, sumamos cantidad
          const existingItemIndex = sale.items.findIndex((it) => it.productId === productToAdd.id);
          let updatedItems = [...sale.items];

          if (existingItemIndex >= 0) {
            const currentItem = updatedItems[existingItemIndex];
            const newQty = currentItem.quantity + qty;
            updatedItems[existingItemIndex] = {
              ...currentItem,
              quantity: newQty,
              subtotal: productToAdd.sellPrice * newQty,
            };
          } else {
            updatedItems.push(cartItem);
          }

          const newTotalAmount = updatedItems.reduce((acc, i) => acc + i.subtotal, 0);
          const newTotalCost = updatedItems.reduce((acc, i) => acc + i.buyPrice * i.quantity, 0);

          return {
            ...sale,
            items: updatedItems,
            totalAmount: newTotalAmount,
            totalCost: newTotalCost,
          };
        })
      );

      addLog(
        'item_added',
        `Producto añadido a Venta #${existingSale.orderNumber}`,
        `Se añadieron +${qty}x "${productToAdd.name}" a la Venta #${existingSale.orderNumber}.`,
        {
          orderNumber: existingSale.orderNumber,
          customerName: existingSale.customerName || 'General',
        }
      );
    }

    setProductToAdd(null);
  };

  // ----------------- MANEJADORES: BOTÓN FLOTANTE HOME (NUEVA VENTA) -----------------
  const handleOpenFloatingSaleModal = () => {
    setFloatingCustomerName('');
    setFloatingPaymentMethod('efectivo');
    setFloatingRows(products.length > 0 ? [{ productId: products[0].id, quantity: 1 }] : []);
    setFloatingError('');
    setIsFloatingSaleModalOpen(true);
  };

  const handleAddFloatingRow = () => {
    if (products.length === 0) return;
    setFloatingRows((prev) => [...prev, { productId: products[0].id, quantity: 1 }]);
  };

  const handleRemoveFloatingRow = (index: number) => {
    setFloatingRows((prev) => prev.filter((_, i) => i !== index));
  };

  const handleConfirmFloatingSale = (e: React.FormEvent) => {
    e.preventDefault();
    if (floatingRows.length === 0) {
      setFloatingError('Debes agregar al menos un producto a la venta.');
      return;
    }

    const items: CartItem[] = [];
    let totalAmount = 0;
    let totalCost = 0;

    for (const row of floatingRows) {
      const prod = products.find((p) => p.id === row.productId);
      if (!prod) continue;
      const qty = Math.max(1, row.quantity || 1);
      if (qty > prod.stock) {
        setFloatingError(`Stock insuficiente para "${prod.name}" (Disponibles: ${prod.stock}).`);
        return;
      }
      const subtotal = prod.sellPrice * qty;
      const cost = prod.buyPrice * qty;

      totalAmount += subtotal;
      totalCost += cost;

      items.push({
        productId: prod.id,
        productName: prod.name,
        buyPrice: prod.buyPrice,
        sellPrice: prod.sellPrice,
        quantity: qty,
        subtotal,
      });
    }

    const currentOrder = orderCounter;
    setOrderCounter((prev) => prev + 1);

    const newSale: ActiveSale = {
      id: 'sale-' + Date.now().toString(),
      orderNumber: currentOrder,
      customerName: floatingCustomerName.trim() || undefined,
      paymentMethod: floatingPaymentMethod,
      items,
      totalAmount,
      totalCost,
      createdAt: new Date().toISOString(),
    };

    setActiveSales((prev) => [newSale, ...prev]);

    addLog(
      'item_added',
      `Nueva Venta #${currentOrder} enviada al carrito`,
      `Venta con ${items.length} producto(s) por $${totalAmount.toFixed(2)} (${floatingPaymentMethod === 'transferencia' ? 'Transferencia al Jefe' : 'Efectivo'}).`,
      {
        orderNumber: currentOrder,
        customerName: floatingCustomerName.trim() || 'General',
        paymentMethod: floatingPaymentMethod,
        totalAmount,
      }
    );

    setIsFloatingSaleModalOpen(false);
    // Cambiar automáticamente a la pestaña de Carrito para ver la venta en proceso
    setActiveTab(1);
  };

  // ----------------- MANEJADORES: TERMINAR Y CANCELAR VENTA EN CARRITO -----------------
  const handleConfirmFinishSale = () => {
    if (!finishingSale) return;

    // 1. Descontar stock de productos
    setProducts((prev) =>
      prev.map((p) => {
        const itemSold = finishingSale.items.find((it) => it.productId === p.id);
        if (itemSold) {
          return {
            ...p,
            stock: Math.max(0, p.stock - itemSold.quantity),
          };
        }
        return p;
      })
    );

    // 2. Crear venta completada
    const now = new Date();
    const completed: CompletedSale = {
      id: finishingSale.id,
      orderNumber: finishingSale.orderNumber,
      customerName: finishingSale.customerName,
      paymentMethod: finishingSale.paymentMethod,
      items: finishingSale.items,
      totalAmount: finishingSale.totalAmount,
      totalCost: finishingSale.totalCost,
      netProfit: finishingSale.totalAmount - finishingSale.totalCost,
      completedAt: now.toISOString(),
      date: now.toISOString().split('T')[0],
    };

    setCompletedSales((prev) => [completed, ...prev]);

    // 3. Quitar de ventas en proceso
    setActiveSales((prev) => prev.filter((s) => s.id !== finishingSale.id));

    // 4. Registrar auditoría
    addLog(
      'sale_completed',
      `Venta #${finishingSale.orderNumber} Completada`,
      `Se finalizó la venta por $${finishingSale.totalAmount.toFixed(2)} pagada en ${finishingSale.paymentMethod === 'transferencia' ? 'Transferencia (Directo al Jefe)' : 'Efectivo'}.`,
      {
        orderNumber: finishingSale.orderNumber,
        customerName: finishingSale.customerName || 'General',
        paymentMethod: finishingSale.paymentMethod,
        totalAmount: finishingSale.totalAmount,
      }
    );

    setFinishingSale(null);
  };

  const handleConfirmCancelSale = () => {
    if (!cancellingSale) return;

    setActiveSales((prev) => prev.filter((s) => s.id !== cancellingSale.id));

    addLog(
      'sale_cancelled',
      `Venta #${cancellingSale.orderNumber} Cancelada`,
      `Se canceló la venta en proceso por $${cancellingSale.totalAmount.toFixed(2)}. No se descontó inventario.`,
      {
        orderNumber: cancellingSale.orderNumber,
        customerName: cancellingSale.customerName || 'General',
      }
    );

    setCancellingSale(null);
  };

  // ----------------- MOTOR: SACAR LAS CUENTAS (LIQUIDACIÓN) -----------------
  const calculatedAccounts = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    const filtered = completedSales.filter((sale) => {
      // Filtro de método de pago
      if (calcPaymentFilter !== 'all' && sale.paymentMethod !== calcPaymentFilter) {
        return false;
      }

      // Filtro de período
      const saleDate = new Date(sale.date + 'T00:00:00');
      if (calcPeriod === 'today') {
        return sale.date === todayStr;
      } else if (calcPeriod === '7days') {
        const diff = (now.getTime() - saleDate.getTime()) / (1000 * 3600 * 24);
        return diff >= 0 && diff <= 7;
      } else if (calcPeriod === '30days') {
        const diff = (now.getTime() - saleDate.getTime()) / (1000 * 3600 * 24);
        return diff >= 0 && diff <= 30;
      }
      return true;
    });

    let totalSold = 0;
    let totalCost = 0;
    let totalCash = 0; // Efectivo recaudado por la vendedora
    let totalTransfer = 0; // Transferencias enviadas al jefe
    let totalItemsCount = 0;

    filtered.forEach((s) => {
      totalSold += s.totalAmount;
      totalCost += s.totalCost;
      if (s.paymentMethod === 'efectivo') {
        totalCash += s.totalAmount;
      } else {
        totalTransfer += s.totalAmount;
      }
      s.items.forEach((it) => {
        totalItemsCount += it.quantity;
      });
    });

    const netProfit = totalSold - totalCost;
    const margin = totalSold > 0 ? (netProfit / totalSold) * 100 : 0;

    return {
      salesCount: filtered.length,
      totalSold,
      totalCost,
      totalCash,
      totalTransfer,
      totalItemsCount,
      netProfit,
      margin,
    };
  }, [completedSales, calcPeriod, calcPaymentFilter]);

  // ----------------- PREVIEW DEL INFORME EN VENTANA DE CREACIÓN -----------------
  const reportPreviewData = useMemo(() => {
    const now = new Date().getTime();

    const filtered = completedSales.filter((sale) => {
      if (reportDaysRange === 'all') return true;
      const saleTime = new Date(sale.completedAt).getTime();
      const diffDays = (now - saleTime) / (1000 * 60 * 60 * 24);
      return diffDays <= reportDaysRange;
    });

    let totalRevenue = 0;
    let totalCash = 0;
    let totalTransfer = 0;
    let totalProductsQty = 0;

    filtered.forEach((sale) => {
      totalRevenue += sale.totalAmount;
      if (sale.paymentMethod === 'efectivo') {
        totalCash += sale.totalAmount;
      } else {
        totalTransfer += sale.totalAmount;
      }
      sale.items.forEach((item) => {
        totalProductsQty += item.quantity;
      });
    });

    const daysLabel =
      reportDaysRange === 'all'
        ? 'Todas las ventas registradas'
        : reportDaysRange === 1
        ? 'Hoy (Últimas 24 horas)'
        : `Últimos ${reportDaysRange} días`;

    return {
      daysLabel,
      salesCount: filtered.length,
      totalRevenue,
      totalCash,
      totalTransfer,
      totalProductsQty,
    };
  }, [completedSales, reportDaysRange]);

  // Crear y guardar un nuevo informe en el registro
  const handleCreateReport = () => {
    const now = new Date().getTime();

    const filtered = completedSales.filter((sale) => {
      if (reportDaysRange === 'all') return true;
      const saleTime = new Date(sale.completedAt).getTime();
      const diffDays = (now - saleTime) / (1000 * 60 * 60 * 24);
      return diffDays <= reportDaysRange;
    });

    const productStats = new Map<string, {
      productId: string;
      productName: string;
      quantity: number;
      sellPrice: number;
      subtotal: number;
    }>();

    let totalRevenue = 0;
    let totalCash = 0;
    let totalTransfer = 0;
    let totalProductsQty = 0;

    filtered.forEach((sale) => {
      totalRevenue += sale.totalAmount;
      if (sale.paymentMethod === 'efectivo') {
        totalCash += sale.totalAmount;
      } else {
        totalTransfer += sale.totalAmount;
      }

      sale.items.forEach((item) => {
        totalProductsQty += item.quantity;
        const existing = productStats.get(item.productId) || {
          productId: item.productId,
          productName: item.productName,
          quantity: 0,
          sellPrice: item.sellPrice,
          subtotal: 0,
        };
        existing.quantity += item.quantity;
        existing.subtotal += item.subtotal;
        productStats.set(item.productId, existing);
      });
    });

    const productsList = Array.from(productStats.values()).sort(
      (a, b) => b.quantity - a.quantity
    );

    const daysLabel =
      reportDaysRange === 'all'
        ? 'Todas las ventas registradas'
        : reportDaysRange === 1
        ? 'Hoy (Últimas 24 horas)'
        : `Últimos ${reportDaysRange} días`;

    const newReport: SalesReport = {
      id: `rep-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      reportNumber: reportCounter,
      createdAt: new Date().toISOString(),
      dateLabel: new Date().toLocaleString(),
      daysRange: reportDaysRange,
      daysLabel,
      salesCount: filtered.length,
      totalProductsQty,
      totalRevenue,
      totalCash,
      totalTransfer,
      productsList,
    };

    setReports((prev) => [newReport, ...prev]);
    setReportCounter((prev) => prev + 1);
    setExpandedReportId(newReport.id);
    setIsReportModalOpen(false);

    addLog(
      'report_created',
      `Informe #${String(reportCounter).padStart(3, '0')} creado`,
      `Período: ${daysLabel}. Total: $${totalRevenue.toFixed(2)} (${filtered.length} ventas, ${totalProductsQty} u.).`
    );

    setReportFeedback(`¡Informe #${String(reportCounter).padStart(3, '0')} creado y guardado en el registro!`);
    setTimeout(() => setReportFeedback(null), 5000);
  };

  // Descargar un informe específico en formato texto
  const handleDownloadReportTxt = (report: SalesReport) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const repNum = String(report.reportNumber).padStart(3, '0');
      let content = `====================================================\n`;
      content += `          INFORME DE VENTAS - BROTHERS\n`;
      content += `====================================================\n`;
      content += `Número de informe: #${repNum}\n`;
      content += `Fecha de emisión : ${report.dateLabel}\n`;
      content += `Período incluido : ${report.daysLabel}\n`;
      content += `Total de ventas  : ${report.salesCount}\n`;
      content += `Unidades totales : ${report.totalProductsQty} u.\n\n`;
      content += `----------------------------------------------------\n`;
      content += `LISTADO DE PRODUCTOS VENDIDOS:\n`;
      content += `----------------------------------------------------\n`;
      if (report.productsList.length === 0) {
        content += `(No se registran productos vendidos en este período)\n`;
      } else {
        report.productsList.forEach((p, idx) => {
          content += `${idx + 1}. ${p.productName}\n`;
          content += `   Cantidad vendida : ${p.quantity} u.\n`;
          content += `   Precio unitario  : $${p.sellPrice.toFixed(2)}\n`;
          content += `   Total producto   : $${p.subtotal.toFixed(2)}\n\n`;
        });
      }
      content += `----------------------------------------------------\n`;
      content += `RESUMEN DE LIQUIDACIÓN Y FONDOS:\n`;
      content += `----------------------------------------------------\n`;
      content += `💵 Efectivo en mano (Caja): $${report.totalCash.toFixed(2)}\n`;
      content += `🏦 Transferencias (Jefe):   $${report.totalTransfer.toFixed(2)}\n`;
      content += `💰 TOTAL GENERAL RECAUDADO: $${report.totalRevenue.toFixed(2)}\n`;
      content += `====================================================\n`;

      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `informe_ventas_#${repNum}_${today}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setReportFeedback(`¡Informe #${repNum} descargado exitosamente en tu dispositivo!`);
      setTimeout(() => setReportFeedback(null), 5000);
    } catch (err) {
      console.error(err);
    }
  };

  // Eliminar un informe del registro
  const handleDeleteReport = (reportId: string) => {
    setReports((prev) => prev.filter((r) => r.id !== reportId));
    if (expandedReportId === reportId) {
      setExpandedReportId(null);
    }
    setReportFeedback('Informe eliminado del registro.');
    setTimeout(() => setReportFeedback(null), 3000);
  };

  // Enviar informe al administrador (Esperando implementación online)
  const handleSendToAdmin = () => {
    setIsWaitingImplementationOpen(true);
  };

  // ----------------- BACKUP / RESTORE JSON -----------------
  const handleExportBackup = () => {
    try {
      const backupData = {
        app: 'Brothers_Venta',
        version: '1.0.0',
        exportedAt: new Date().toISOString(),
        products,
        activeSales,
        completedSales,
        logs,
        orderCounter,
        reports,
        reportCounter,
      };
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `copia_seguridad_brothers_venta_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setBackupMessage('¡Copia de seguridad descargada exitosamente!');
      setTimeout(() => setBackupMessage(null), 4000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (data.products && Array.isArray(data.products)) setProducts(data.products);
        if (data.activeSales && Array.isArray(data.activeSales)) setActiveSales(data.activeSales);
        if (data.completedSales && Array.isArray(data.completedSales)) setCompletedSales(data.completedSales);
        if (data.logs && Array.isArray(data.logs)) setLogs(data.logs);
        if (data.orderCounter) setOrderCounter(data.orderCounter);
        if (data.reports && Array.isArray(data.reports)) setReports(data.reports);
        if (data.reportCounter) setReportCounter(data.reportCounter);

        addLog('backup_restored', 'Copia de seguridad restaurada', 'Se importaron los datos correctamente.');
        setBackupMessage('¡Copia de seguridad restaurada con éxito!');
        setTimeout(() => setBackupMessage(null), 5000);
        setIsBackupModalOpen(false);
      } catch (err) {
        alert('El archivo no es una copia de seguridad válida.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Generador de ZIP para el NUEVO repositorio en GitHub
  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      zip.file('package.json', PACKAGE_JSON);
      zip.file('capacitor.config.json', CAPACITOR_CONFIG);
      zip.file('index.html', INDEX_HTML);
      zip.file('vite.config.ts', VITE_CONFIG);
      zip.file('tsconfig.json', TSCONFIG_JSON);

      // Workflow de compilación para Android con firma fija
      const githubFolder = zip.folder('.github');
      if (githubFolder) {
        const workflowsFolder = githubFolder.folder('workflows');
        if (workflowsFolder) {
          workflowsFolder.file('build-apk.yml', WORKFLOW_YML);
        }
      }

      const srcFolder = zip.folder('src');
      if (srcFolder) {
        srcFolder.file('index.css', SRC_INDEX_CSS);
        srcFolder.file('main.tsx', SRC_MAIN_TSX);
        srcFolder.file('types.ts', SRC_TYPES_TS);
        srcFolder.file('projectFiles.ts', SRC_PROJECT_FILES_TS);
        srcFolder.file('App.tsx', getSrcAppTsx());
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'brothers-venta.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 5000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsZipping(false);
    }
  };

  // Menú inferior: 5 Botones
  // 0: Inicio
  // 1: Carrito (en lugar de Categorías!)
  // 2: Ventas
  // 3: Registros
  // 4: Informe (en lugar de Cuentas!)
  const navButtons = [
    { id: 0, label: 'Inicio', icon: HomeIcon, badge: 0 },
    { id: 1, label: 'Carrito', icon: ShoppingCart, badge: activeSales.length },
    { id: 2, label: 'Ventas', icon: Receipt, badge: 0 },
    { id: 3, label: 'Registros', icon: ClipboardList, badge: 0 },
    { id: 4, label: 'Informe', icon: FileText, badge: 0 },
  ];

  // 1. Splash Screen
  if (showSplash) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-950 flex flex-col items-center justify-center p-6 text-white select-none">
        <div className="w-full max-w-sm flex flex-col items-center text-center">
          <div className="relative mb-8">
            <div className="w-28 h-28 rounded-3xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center shadow-2xl shadow-emerald-500/10 backdrop-blur-md animate-pulse">
              <ShoppingBag className="w-16 h-16 text-emerald-400 stroke-[1.75]" />
            </div>
          </div>

          <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
            Brothers_Venta
          </h1>
          <p className="text-sm font-medium text-slate-400 mb-8">
            Punto de Venta Móvil para Vendedoras
          </p>

          <div className="w-full bg-slate-700/60 rounded-full h-3 overflow-hidden p-0.5 border border-slate-600/40 shadow-inner">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-75 ease-linear"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>

          <div className="mt-3 flex justify-between w-full text-xs font-mono text-slate-400">
            <span>Iniciando ventas...</span>
            <span>{Math.round(Math.min(progress, 100))}%</span>
          </div>
        </div>
      </div>
    );
  }

  // 2. Pantalla Principal
  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800 antialiased select-none">
      {/* Header Superior Fijo */}
      <header className="sticky top-0 z-20 bg-white border-b border-slate-200 px-4 py-3 shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <ShoppingBag className="w-5 h-5 stroke-[2]" />
            </div>
            <div>
              <h1 className="font-bold text-base text-slate-900 leading-tight">
                Brothers_Venta
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                {navButtons[activeTab].label}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsBackupModalOpen(true)}
              className="p-1.5 text-slate-600 hover:text-emerald-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Copia de Seguridad"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
            </button>

            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center gap-1.5 text-xs text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 px-2.5 py-1.5 rounded-lg font-medium transition-colors shadow-xs"
              title="Descargar ZIP para el nuevo repositorio de GitHub"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isZipping ? '...' : '.ZIP'}</span>
            </button>

            <button
              onClick={() => setShowSplash(true)}
              className="p-1.5 text-slate-500 hover:text-emerald-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Ver Splash Screen"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Contenido Principal */}
      <main className="flex-1 max-w-md w-full mx-auto p-4 pb-28">
        {/* Banner de Copia de Seguridad */}
        {backupMessage && (
          <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-3 flex items-center gap-2 text-xs animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{backupMessage}</span>
          </div>
        )}

        {/* Banner de descarga de ZIP */}
        {downloadSuccess && (
          <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-3 flex items-center gap-2 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>¡Archivo <strong>brothers-venta.zip</strong> descargado! Súbelo a tu nuevo repositorio de GitHub para crear la aplicación.</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 0. INICIO (CATÁLOGO DE PRODUCTOS - SOLO CONSULTA Y AGREGAR AL CARRITO)    */}
        {/* ========================================================================= */}
        {activeTab === 0 && (
          <div>
            {/* Buscador y Categorías */}
            <div className="mb-4 space-y-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Buscar producto a vender..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 shadow-xs"
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                {availableCategories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 rounded-full whitespace-nowrap font-medium transition-colors cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-emerald-600 text-white'
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Listado de Productos */}
            {filteredProducts.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center shadow-xs">
                <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">Sin resultados</p>
                <p className="text-xs text-slate-500 mt-1">No se encontraron productos para los filtros.</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-1">
                  <span>Productos Disponibles ({filteredProducts.length})</span>
                  <span>Stock total: {filteredProducts.reduce((acc, p) => acc + p.stock, 0)} u.</span>
                </div>

                {filteredProducts.map((p) => {
                  const isOutOfStock = p.stock <= 0;
                  return (
                    <div
                      key={p.id}
                      className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-slate-300 transition-all"
                    >
                      <div className="flex items-start justify-between gap-2 mb-2.5">
                        <div className="flex-1">
                          <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                            {p.category}
                          </span>
                          <h4 className="text-sm font-bold text-slate-900 mt-1 leading-snug">
                            {p.name}
                          </h4>
                        </div>

                        <div
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold text-center shrink-0 border ${
                            p.stock <= 0
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : p.stock <= 5
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}
                        >
                          <span className="block text-[10px] uppercase font-medium opacity-80">Stock</span>
                          <span>{p.stock} u.</span>
                        </div>
                      </div>

                      {/* Detalles de Precios (Mismas características de Almacén) */}
                      <div className="grid grid-cols-2 gap-2 bg-slate-50/80 rounded-xl p-2.5 border border-slate-100 text-xs mb-3">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-medium">Precio Compra</span>
                          <span className="font-semibold text-slate-700">${p.buyPrice.toFixed(2)}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-medium">Precio Venta</span>
                          <span className="font-bold text-emerald-600 text-sm">${p.sellPrice.toFixed(2)}</span>
                        </div>
                      </div>

                      {/* Botón único: AGREGAR AL CARRITO (Sin editar, crear ni eliminar) */}
                      <button
                        onClick={() => handleOpenAddProductModal(p)}
                        disabled={isOutOfStock}
                        className={`w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl font-bold text-xs transition-all active:scale-98 cursor-pointer shadow-xs ${
                          isOutOfStock
                            ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        }`}
                      >
                        <ShoppingCart className="w-4 h-4" />
                        <span>{isOutOfStock ? 'Agotado en Almacén' : 'Agregar al Carrito'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* 1. CARRITO (VENTAS EN PROCESO - SUSTITUYE AL BOTÓN DE CATEGORÍAS)         */}
        {/* ========================================================================= */}
        {activeTab === 1 && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-emerald-600" />
                  <span>Carrito de Ventas</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Ventas activas en proceso. Termínalas o cancélalas aquí.
                </p>
              </div>
              <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full">
                {activeSales.length} {activeSales.length === 1 ? 'venta' : 'ventas'}
              </span>
            </div>

            {activeSales.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 shadow-xs flex flex-col items-center">
                <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
                  <ShoppingCart className="w-8 h-8" />
                </div>
                <h3 className="text-sm font-bold text-slate-800">El carrito está vacío</h3>
                <p className="text-xs text-slate-500 mt-1 mb-4 max-w-xs">
                  Ve a la pestaña de Inicio para agregar productos al carrito o presiona el botón flotante para crear una nueva venta.
                </p>
                <button
                  onClick={() => setActiveTab(0)}
                  className="bg-emerald-600 text-white text-xs font-semibold px-4 py-2 rounded-xl active:scale-95 cursor-pointer shadow-xs"
                >
                  Ver Productos
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {activeSales.map((sale) => (
                  <div
                    key={sale.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3"
                  >
                    {/* Cabecera de la venta en proceso */}
                    <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold bg-slate-900 text-white px-2 py-0.5 rounded-lg">
                            Venta #{sale.orderNumber}
                          </span>
                          {sale.paymentMethod === 'transferencia' ? (
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1">
                              <Building2 className="w-3 h-3" />
                              <span>Transferencia (Jefe)</span>
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                              <Banknote className="w-3 h-3" />
                              <span>Efectivo</span>
                            </span>
                          )}
                        </div>

                        {sale.customerName ? (
                          <p className="text-xs font-semibold text-slate-800 mt-1 flex items-center gap-1">
                            <User className="w-3 h-3 text-slate-400" />
                            <span>Cliente: {sale.customerName}</span>
                          </p>
                        ) : (
                          <p className="text-xs text-slate-400 mt-1 italic">Cliente: General</p>
                        )}
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-medium block">Total</span>
                        <span className="text-base font-extrabold text-emerald-600">
                          ${sale.totalAmount.toFixed(2)}
                        </span>
                      </div>
                    </div>

                    {/* Lista de productos en esta venta */}
                    <div className="space-y-1.5 py-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                        Productos en esta venta:
                      </span>
                      {sale.items.map((item, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between text-xs py-1.5 px-2.5 bg-slate-50 rounded-xl"
                        >
                          <div className="flex-1">
                            <span className="font-bold text-slate-800">{item.productName}</span>
                            <span className="text-slate-400 text-[11px] ml-1.5 font-mono">
                              ({item.quantity} u. × ${item.sellPrice.toFixed(2)})
                            </span>
                          </div>
                          <span className="font-bold text-slate-900">${item.subtotal.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    {/* Aviso si es transferencia */}
                    {sale.paymentMethod === 'transferencia' && (
                      <div className="p-2 bg-blue-50/70 border border-blue-100 rounded-xl text-[11px] text-blue-800 flex items-center gap-1.5">
                        <Building2 className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>Pago por transferencia: este dinero se envía directamente a la cuenta del jefe.</span>
                      </div>
                    )}

                    {/* Opciones: Terminar venta o Cancelarla (con confirmación) */}
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                      <button
                        onClick={() => setCancellingSale(sale)}
                        className="py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold rounded-xl text-xs transition-colors active:scale-95 cursor-pointer flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Cancelar</span>
                      </button>

                      <button
                        onClick={() => setFinishingSale(sale)}
                        className="flex-1 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-colors active:scale-95 cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                      >
                        <Check className="w-4 h-4 stroke-[2.5]" />
                        <span>Terminar Venta (${sale.totalAmount.toFixed(2)})</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* 2. VENTAS (HISTORIAL DE VENTAS COMPLETADAS)                              */}
        {/* ========================================================================= */}
        {activeTab === 2 && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-emerald-600" />
                  <span>Historial de Ventas</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Ventas terminadas y registradas en caja.
                </p>
              </div>
              <span className="text-xs font-bold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full">
                {completedSales.length}
              </span>
            </div>

            {completedSales.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 shadow-xs">
                <Receipt className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">Sin ventas completadas</p>
                <p className="text-xs text-slate-400 mt-1">
                  Cuando termines una venta desde el carrito aparecerá listada aquí.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {completedSales.map((sale) => (
                  <div
                    key={sale.id}
                    className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-slate-300 transition-all space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-2 pb-2 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            Venta #{sale.orderNumber}
                          </span>
                          {sale.paymentMethod === 'transferencia' ? (
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
                              Transferencia (Jefe)
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                              Efectivo
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Cliente: <strong>{sale.customerName || 'General'}</strong>
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-bold text-emerald-600 block">
                          ${sale.totalAmount.toFixed(2)}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {sale.date}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-1 text-xs text-slate-600">
                      {sale.items.map((it, i) => (
                        <div key={i} className="flex justify-between">
                          <span>
                            {it.quantity}x {it.productName}
                          </span>
                          <span className="font-semibold text-slate-700">${it.subtotal.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* 3. REGISTROS (AUDITORÍA DE ACTIVIDAD)                                     */}
        {/* ========================================================================= */}
        {activeTab === 3 && (
          <div className="space-y-3">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-emerald-600" />
                <span>Registro de Actividad</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Historial auditado de cada venta, cancelación y movimiento en la app.
              </p>
            </div>

            {logs.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 shadow-xs">
                <ClipboardList className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">Sin notificaciones de actividad</p>
                <p className="text-xs text-slate-400 mt-1">
                  Las acciones de venta quedarán registradas aquí.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {logs.map((log) => {
                  const date = new Date(log.timestamp);
                  const formattedTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

                  let badgeColor = 'bg-slate-100 text-slate-700';
                  if (log.type === 'sale_completed') badgeColor = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                  if (log.type === 'sale_cancelled') badgeColor = 'bg-rose-50 text-rose-700 border-rose-200';
                  if (log.type === 'item_added') badgeColor = 'bg-blue-50 text-blue-700 border-blue-200';

                  return (
                    <div
                      key={log.id}
                      className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${badgeColor}`}>
                          {log.title}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {formattedTime}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed mt-1">
                        {log.description}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* 4. INFORME (REGISTRO DE INFORMES CREADOS)                                */}
        {/* ========================================================================= */}
        {activeTab === 4 && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  <span>Registro de Informes</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Historial de todos los informes creados.
                </p>
              </div>
              <span className="text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-full">
                {reports.length} {reports.length === 1 ? 'informe' : 'informes'}
              </span>
            </div>

            {/* Notificación de feedback si se creó o descargó un informe */}
            {reportFeedback && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs flex items-center gap-2 animate-in fade-in shadow-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-medium">{reportFeedback}</span>
              </div>
            )}

            {/* Modal de confirmación para eliminar informe si se desea */}
            {reportToDelete && (
              <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
                <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 text-xs text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center border border-rose-200">
                    <Trash2 className="w-6 h-6 stroke-[2]" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      ¿Eliminar este informe?
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Se eliminará el <strong>Informe #{String(reportToDelete.reportNumber).padStart(3, '0')}</strong> del registro local. Las ventas registradas permanecerán intactas.
                    </p>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setReportToDelete(null)}
                      className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleDeleteReport(reportToDelete.id);
                        setReportToDelete(null);
                      }}
                      className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl cursor-pointer"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Listado de Informes Creados */}
            {reports.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xs text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center border border-emerald-100">
                  <FileText className="w-8 h-8 stroke-[1.8]" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-slate-800">
                    No hay informes creados todavía
                  </h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                    Para generar un informe nuevo, pulsa el botón flotante verde <strong>"Crear Informe"</strong> ubicado abajo a la derecha.
                  </p>
                </div>
                <div className="pt-2 flex items-center justify-center gap-1.5 text-[11px] text-emerald-700 font-semibold bg-emerald-50/70 border border-emerald-200/60 rounded-xl py-2 px-3 max-w-xs mx-auto">
                  <Plus className="w-3.5 h-3.5" />
                  <span>Usa el botón flotante inferior para crear uno</span>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {reports.map((report) => {
                  const isExpanded = expandedReportId === report.id;
                  const repNum = String(report.reportNumber).padStart(3, '0');

                  return (
                    <div
                      key={report.id}
                      className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden transition-all"
                    >
                      {/* Cabecera del informe (siempre visible, al tocar despliega/repliega) */}
                      <button
                        type="button"
                        onClick={() => setExpandedReportId(isExpanded ? null : report.id)}
                        className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50/60 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                            isExpanded ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}>
                            <FileText className="w-5 h-5 stroke-[2]" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-black text-slate-900 text-sm">
                                Informe #{repNum}
                              </h3>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                                {report.daysLabel}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              <span>{report.dateLabel}</span>
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <span className="text-sm font-black text-emerald-600 block">
                              ${report.totalRevenue.toFixed(2)}
                            </span>
                            <span className="text-[10px] text-slate-400 font-medium">
                              {report.salesCount} vtas • {report.totalProductsQty} u.
                            </span>
                          </div>
                          <div className="text-slate-400">
                            {isExpanded ? (
                              <ChevronUp className="w-5 h-5" />
                            ) : (
                              <ChevronDown className="w-5 h-5" />
                            )}
                          </div>
                        </div>
                      </button>

                      {/* Contenido desplegado del informe específico */}
                      {isExpanded && (
                        <div className="px-4 pb-4 pt-1 border-t border-slate-100 space-y-3.5 bg-slate-50/40">
                          {/* Resumen de Liquidación de este informe */}
                          <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                            <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl">
                              <span className="text-[10px] text-emerald-800 font-bold uppercase block">💵 Efectivo (Caja)</span>
                              <span className="text-base font-black text-emerald-700">${report.totalCash.toFixed(2)}</span>
                              <span className="text-[9px] text-emerald-600 block mt-0.5">Dinero físico en mano</span>
                            </div>

                            <div className="bg-blue-50 border border-blue-200 p-2.5 rounded-xl">
                              <span className="text-[10px] text-blue-800 font-bold uppercase block">🏦 Transferencias (Jefe)</span>
                              <span className="text-base font-black text-blue-700">${report.totalTransfer.toFixed(2)}</span>
                              <span className="text-[9px] text-blue-600 block mt-0.5">Directo en banco del jefe</span>
                            </div>
                          </div>

                          {/* Totales complementarios */}
                          <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                            <div>
                              <span className="text-[11px] text-slate-500 font-medium block">Ventas incluidas: <strong>{report.salesCount}</strong></span>
                              <span className="text-[11px] text-slate-500 font-medium block">Total unidades: <strong>{report.totalProductsQty} u.</strong></span>
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Recaudado</span>
                              <span className="text-base font-black text-slate-900">${report.totalRevenue.toFixed(2)}</span>
                            </div>
                          </div>

                          {/* Listado de productos vendidos en este informe */}
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                                Productos Vendidos ({report.productsList.length})
                              </span>
                            </div>

                            {report.productsList.length === 0 ? (
                              <div className="p-4 bg-white rounded-xl border border-slate-200 text-center text-slate-400 text-xs">
                                No se registraron productos vendidos en el período seleccionado.
                              </div>
                            ) : (
                              <div className="space-y-1.5 max-h-60 overflow-y-auto pr-0.5">
                                {report.productsList.map((prod, idx) => (
                                  <div
                                    key={idx}
                                    className="p-2.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                                  >
                                    <div className="space-y-0.5">
                                      <p className="font-bold text-slate-900">{prod.productName}</p>
                                      <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                                        <span className="font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                                          {prod.quantity} u.
                                        </span>
                                        <span>×</span>
                                        <span>${prod.sellPrice.toFixed(2)} c/u</span>
                                      </div>
                                    </div>
                                    <div className="text-right">
                                      <span className="text-[9px] text-slate-400 font-medium block">Subtotal</span>
                                      <span className="font-bold text-emerald-600 text-xs">
                                        ${prod.subtotal.toFixed(2)}
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* Botones de acción del informe específico: Descargar y Enviar al Administrador */}
                          <div className="pt-1 flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleDownloadReportTxt(report)}
                              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold rounded-xl active:scale-95 transition-all cursor-pointer shadow-xs text-xs"
                            >
                              <Download className="w-4 h-4 text-emerald-600" />
                              <span>Descargar</span>
                            </button>

                            <button
                              type="button"
                              onClick={handleSendToAdmin}
                              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl active:scale-95 transition-all cursor-pointer shadow-xs text-xs"
                            >
                              <Send className="w-4 h-4" />
                              <span>Enviar al Administrador</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => setReportToDelete(report)}
                              className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-xl active:scale-95 transition-all cursor-pointer"
                              title="Eliminar este informe del registro"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>

      {/* ========================================================================= */}
      {/* BOTÓN FLOTANTE 1: SOLO EN HOME (REALIZAR NUEVA VENTA)                     */}
      {/* ========================================================================= */}
      {activeTab === 0 && (
        <button
          onClick={handleOpenFloatingSaleModal}
          className="fixed right-5 bottom-20 z-30 px-4 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xl shadow-emerald-600/30 flex items-center gap-2 font-bold text-xs active:scale-95 transition-all cursor-pointer"
          title="Realizar Nueva Venta"
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>Nueva Venta</span>
        </button>
      )}

      {/* ========================================================================= */}
      {/* BOTÓN FLOTANTE 2: SOLO EN INFORME (CREAR INFORME)                         */}
      {/* ========================================================================= */}
      {activeTab === 4 && (
        <button
          onClick={() => {
            setReportFeedback(null);
            setIsReportModalOpen(true);
          }}
          className="fixed right-5 bottom-20 z-30 px-4 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xl shadow-emerald-600/30 flex items-center gap-2 font-bold text-xs active:scale-95 transition-all cursor-pointer"
          title="Crear Informe de Ventas"
        >
          <FileText className="w-5 h-5 stroke-[2.2]" />
          <span>Crear Informe</span>
        </button>
      )}

      {/* ========================================================================= */}
      {/* MENÚ INFERIOR FIJO: 5 BOTONES                                             */}
      {/* ========================================================================= */}
      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 shadow-lg z-40">
        <div className="max-w-md mx-auto grid grid-cols-5 h-16 px-1">
          {navButtons.map((btn) => {
            const Icon = btn.icon;
            const isActive = activeTab === btn.id;
            return (
              <button
                key={btn.id}
                onClick={() => setActiveTab(btn.id)}
                type="button"
                className={`relative flex flex-col items-center justify-center py-1 transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'text-emerald-600 font-semibold'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <div
                  className={`p-1 rounded-xl transition-colors relative ${
                    isActive ? 'bg-emerald-50' : 'bg-transparent'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.2]' : 'stroke-[1.75]'}`} />
                  {btn.badge > 0 && (
                    <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[9px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                      {btn.badge}
                    </span>
                  )}
                </div>
                <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-full px-1">
                  {btn.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* ========================================================================= */}
      {/* MODAL 1: AGREGAR PRODUCTO INDIVIDUAL AL CARRITO                           */}
      {/* (Pregunta si es a una venta nueva o a una en proceso)                     */}
      {/* ========================================================================= */}
      {productToAdd && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 text-xs">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Agregar al Carrito</h3>
                <p className="text-[11px] text-slate-500">{productToAdd.name}</p>
              </div>
              <button
                onClick={() => setProductToAdd(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmAddProduct} className="space-y-3.5">
              {/* Cantidad a agregar */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-[11px] font-bold text-slate-700 uppercase">Cantidad:</label>
                  <span className="text-[11px] text-slate-500">Stock: {productToAdd.stock} u.</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setAddQuantity((q) => Math.max(1, q - 1))}
                    className="w-10 h-10 rounded-xl bg-white border border-slate-200 text-slate-700 font-bold text-base flex items-center justify-center active:scale-95 cursor-pointer"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    max={productToAdd.stock}
                    value={addQuantity}
                    onChange={(e) =>
                      setAddQuantity(Math.min(productToAdd.stock, Math.max(1, parseInt(e.target.value, 10) || 1)))
                    }
                    className="flex-1 bg-white border border-slate-200 rounded-xl py-2 text-center text-sm font-bold text-slate-800"
                  />
                  <button
                    type="button"
                    onClick={() => setAddQuantity((q) => Math.min(productToAdd.stock, q + 1))}
                    className="w-10 h-10 rounded-xl bg-white border border-slate-200 text-slate-700 font-bold text-base flex items-center justify-center active:scale-95 cursor-pointer"
                  >
                    +
                  </button>
                </div>
                <div className="mt-2 text-right text-xs font-bold text-emerald-600">
                  Subtotal: ${(productToAdd.sellPrice * addQuantity).toFixed(2)}
                </div>
              </div>

              {/* ¿A cuál venta agregar? (Nueva venta o venta existente en proceso) */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2">
                <label className="text-[11px] font-bold text-slate-700 uppercase block">
                  ¿A cuál venta deseas agregar este producto?
                </label>

                {activeSales.length === 0 ? (
                  <p className="text-[11px] text-slate-500">
                    No hay ventas activas en el carrito. Se creará una <strong>Nueva Venta</strong>.
                  </p>
                ) : (
                  <div className="space-y-1.5 text-xs">
                    <label className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer">
                      <input
                        type="radio"
                        name="targetSale"
                        checked={targetSaleMode === 'new'}
                        onChange={() => setTargetSaleMode('new')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="font-semibold text-slate-800">+ Crear una Nueva Venta</span>
                    </label>

                    {activeSales.map((sale) => (
                      <label
                        key={sale.id}
                        className="flex items-center gap-2 p-2 bg-white rounded-xl border border-slate-200 cursor-pointer"
                      >
                        <input
                          type="radio"
                          name="targetSale"
                          checked={targetSaleMode === sale.id}
                          onChange={() => setTargetSaleMode(sale.id)}
                          className="text-emerald-600 focus:ring-emerald-500"
                        />
                        <div className="flex-1 flex justify-between items-center text-[11px]">
                          <span>
                            <strong>Venta #{sale.orderNumber}</strong> ({sale.customerName || 'General'})
                          </span>
                          <span className="text-slate-400 font-mono">${sale.totalAmount.toFixed(2)}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Si es una nueva venta: Pedir cliente opcional y método de pago */}
              {(targetSaleMode === 'new' || activeSales.length === 0) && (
                <div className="space-y-2.5 pt-1">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                      Nombre del Cliente (Opcional)
                    </label>
                    <input
                      type="text"
                      placeholder="Ej: Carmen Gómez"
                      value={targetCustomerName}
                      onChange={(e) => setTargetCustomerName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                      Método de Pago *
                    </label>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <button
                        type="button"
                        onClick={() => setTargetPaymentMethod('efectivo')}
                        className={`py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                          targetPaymentMethod === 'efectivo'
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-700'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <Banknote className="w-4 h-4" />
                        <span>Efectivo</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setTargetPaymentMethod('transferencia')}
                        className={`py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                          targetPaymentMethod === 'transferencia'
                            ? 'bg-blue-50 border-blue-500 text-blue-700'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <Building2 className="w-4 h-4" />
                        <span>Transferencia</span>
                      </button>
                    </div>

                    {targetPaymentMethod === 'transferencia' && (
                      <p className="text-[10px] text-blue-600 mt-1 italic">
                        * Nota: El dinero de transferencias va directamente al jefe.
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setProductToAdd(null)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold cursor-pointer shadow-xs"
                >
                  Confirmar y Agregar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: NUEVA VENTA COMPLETA DESDE BOTÓN FLOTANTE EN HOME                */}
      {/* ========================================================================= */}
      {isFloatingSaleModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm mx-auto rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-xs">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Realizar Nueva Venta</h3>
                <p className="text-[11px] text-slate-500">Agrega productos y envíalos al carrito</p>
              </div>
              <button
                onClick={() => setIsFloatingSaleModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmFloatingSale} className="p-4 overflow-y-auto space-y-3.5 flex-1">
              {floatingError && (
                <div className="p-2 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-[11px]">
                  {floatingError}
                </div>
              )}

              {/* Nombre de cliente (Opcional) */}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Nombre del Cliente (Opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ej: Juan Pérez"
                  value={floatingCustomerName}
                  onChange={(e) => setFloatingCustomerName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Método de pago */}
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Método de Pago *
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setFloatingPaymentMethod('efectivo')}
                    className={`py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      floatingPaymentMethod === 'efectivo'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-700'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Banknote className="w-4 h-4" />
                    <span>Efectivo</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFloatingPaymentMethod('transferencia')}
                    className={`py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      floatingPaymentMethod === 'transferencia'
                        ? 'bg-blue-50 border-blue-500 text-blue-700'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>Transferencia</span>
                  </button>
                </div>

                {floatingPaymentMethod === 'transferencia' && (
                  <div className="mt-1.5 p-2 bg-blue-50 rounded-xl border border-blue-100 text-[10px] text-blue-800">
                    💰 <strong>Importante:</strong> Las compras por transferencia van directas al jefe. En el reporte se computan por separado para la liquidación.
                  </div>
                )}
              </div>

              {/* Productos y Cantidades */}
              <div className="space-y-2 pt-1 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-slate-800 uppercase">
                    Productos a vender:
                  </label>
                  <button
                    type="button"
                    onClick={handleAddFloatingRow}
                    className="text-emerald-600 hover:text-emerald-800 font-semibold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Agregar fila</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {floatingRows.map((row, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200"
                    >
                      <div className="flex-1">
                        <select
                          value={row.productId}
                          onChange={(e) => {
                            const newId = e.target.value;
                            setFloatingRows((prev) =>
                              prev.map((r, i) => (i === idx ? { ...r, productId: newId } : r))
                            );
                          }}
                          className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs text-slate-800"
                        >
                          {products.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} (${p.sellPrice.toFixed(2)}) - Stock: {p.stock}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="w-20">
                        <input
                          type="number"
                          min="1"
                          value={row.quantity}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10) || 1;
                            setFloatingRows((prev) =>
                              prev.map((r, i) => (i === idx ? { ...r, quantity: val } : r))
                            );
                          }}
                          className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs text-center font-bold"
                          placeholder="Cant"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveFloatingRow(idx)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFloatingSaleModalOpen(false)}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold cursor-pointer shadow-xs"
                >
                  Enviar al Carrito
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CONFIRMAR TERMINAR VENTA                                         */}
      {/* ========================================================================= */}
      {finishingSale && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 text-xs text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center mb-3">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">
              ¿Finalizar Venta #{finishingSale.orderNumber}?
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Monto a cobrar: <strong className="text-emerald-600">${finishingSale.totalAmount.toFixed(2)}</strong> ({finishingSale.paymentMethod === 'transferencia' ? 'Transferencia al Jefe' : 'Efectivo en mano'}).
            </p>
            <p className="text-[11px] text-slate-400 mb-4">
              Se descontarán las unidades vendidas del stock y se registrará la venta en caja.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setFinishingSale(null)}
                className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium cursor-pointer"
              >
                Volver
              </button>
              <button
                onClick={handleConfirmFinishSale}
                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold cursor-pointer"
              >
                Confirmar y Cobrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: CONFIRMAR CANCELAR VENTA (PIDE CONFIRMACIÓN)                      */}
      {/* ========================================================================= */}
      {cancellingSale && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 text-xs text-center">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">
              ¿Cancelar Venta #{cancellingSale.orderNumber}?
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Esta venta será eliminada del carrito. No se descontará inventario ni se registrará cobro.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setCancellingSale(null)}
                className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium cursor-pointer"
              >
                No, mantenerla
              </button>
              <button
                onClick={handleConfirmCancelSale}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold cursor-pointer"
              >
                Sí, cancelar venta
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: SACAR LAS CUENTAS (LIQUIDACIÓN COMPLETA)                         */}
      {/* ========================================================================= */}
      {isCalculateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-md mx-auto rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Calculator className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm leading-tight">Sacar las Cuentas</h3>
                  <p className="text-[11px] text-slate-400">Balance de ventas, efectivo y transferencias</p>
                </div>
              </div>
              <button
                onClick={() => setIsCalculateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 text-xs">
              {/* Filtro período */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <label className="text-[11px] font-bold text-slate-700 block mb-1.5 uppercase">
                  Período:
                </label>
                <div className="grid grid-cols-4 gap-1 text-[11px]">
                  {[
                    { id: 'today', label: 'Hoy' },
                    { id: '7days', label: '7 Días' },
                    { id: '30days', label: '30 Días' },
                    { id: 'all', label: 'Todo' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setCalcPeriod(p.id as any)}
                      className={`py-1.5 px-2 rounded-xl font-medium border text-center transition-colors cursor-pointer ${
                        calcPeriod === p.id
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Filtro método de pago */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <label className="text-[11px] font-bold text-slate-700 block mb-1.5 uppercase">
                  Filtrar por Forma de Pago:
                </label>
                <div className="grid grid-cols-3 gap-1 text-[11px]">
                  {[
                    { id: 'all', label: 'Todos' },
                    { id: 'efectivo', label: 'Solo Efectivo' },
                    { id: 'transferencia', label: 'Solo Transferencia' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setCalcPaymentFilter(f.id as any)}
                      className={`py-1.5 px-1.5 rounded-xl font-medium border text-center transition-colors cursor-pointer truncate ${
                        calcPaymentFilter === f.id
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Resumen */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-2xl">
                  <span className="text-[10px] text-emerald-800 uppercase font-bold block">💵 Efectivo a Entregar</span>
                  <p className="text-xl font-black text-emerald-700 mt-0.5">
                    ${calculatedAccounts.totalCash.toFixed(2)}
                  </p>
                </div>

                <div className="bg-blue-50 border border-blue-200 p-3 rounded-2xl">
                  <span className="text-[10px] text-blue-800 uppercase font-bold block">🏦 Transferencias al Jefe</span>
                  <p className="text-xl font-black text-blue-700 mt-0.5">
                    ${calculatedAccounts.totalTransfer.toFixed(2)}
                  </p>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl">
                  <span className="text-[10px] text-slate-500 uppercase font-medium block">Total Vendido</span>
                  <p className="text-lg font-bold text-slate-900 mt-0.5">
                    ${calculatedAccounts.totalSold.toFixed(2)}
                  </p>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-3 rounded-2xl">
                  <span className="text-[10px] text-slate-500 uppercase font-medium block">Ganancia Estimada</span>
                  <p className="text-lg font-bold text-emerald-600 mt-0.5">
                    ${calculatedAccounts.netProfit.toFixed(2)}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-slate-200 bg-slate-50">
              <button
                onClick={() => setIsCalculateModalOpen(false)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs cursor-pointer"
              >
                Cerrar Balance
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: COPIA DE SEGURIDAD (RESPALDAR / RESTAURAR DATOS)                  */}
      {/* ========================================================================= */}
      {isBackupModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 text-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Copia de Seguridad</h3>
                  <p className="text-[11px] text-slate-500">Brothers_Venta</p>
                </div>
              </div>
              <button
                onClick={() => setIsBackupModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 my-3">
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2 text-slate-800 font-bold mb-1">
                  <FileDown className="w-4 h-4 text-emerald-600" />
                  <span>1. Descargar Respaldo</span>
                </div>
                <p className="text-[11px] text-slate-500 mb-2.5">
                  Guarda un archivo <strong>.JSON</strong> en tu teléfono con las ventas, carrito y catálogo.
                </p>
                <button
                  onClick={handleExportBackup}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold text-xs active:scale-95 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar Copia (.JSON)</span>
                </button>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2 text-slate-800 font-bold mb-1">
                  <FileUp className="w-4 h-4 text-blue-600" />
                  <span>2. Restaurar Respaldo</span>
                </div>
                <p className="text-[11px] text-slate-500 mb-2.5">
                  Carga un archivo <strong>.JSON</strong> previamente guardado para recuperar tus ventas.
                </p>
                <label className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-xs active:scale-95 cursor-pointer shadow-xs">
                  <FileUp className="w-3.5 h-3.5" />
                  <span>Cargar Archivo .JSON</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => setIsBackupModalOpen(false)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium cursor-pointer text-xs"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 7: CREAR NUEVO INFORME DE VENTAS (SOLO CREAR O CANCELAR)            */}
      {/* ========================================================================= */}
      {isReportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-md mx-auto rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-xs">
            {/* Header del modal */}
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm leading-tight">Crear Nuevo Informe</h3>
                  <p className="text-[11px] text-slate-400">Selecciona el período de ventas a incluir</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsReportModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Contenido del modal de creación */}
            <div className="p-4 overflow-y-auto space-y-4 flex-1">
              {/* Selector de días */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Filter className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Días a incluir en el informe:</span>
                  </label>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                    {reportPreviewData.daysLabel}
                  </span>
                </div>

                {/* Botones rápidos de selección */}
                <div className="grid grid-cols-3 gap-1.5 text-xs font-medium">
                  {[
                    { label: 'Hoy (1 d)', val: 1 },
                    { label: '3 días', val: 3 },
                    { label: '7 días', val: 7 },
                    { label: '15 días', val: 15 },
                    { label: '30 días', val: 30 },
                    { label: 'Todas', val: 'all' as const },
                  ].map((item) => {
                    const isSelected = reportDaysRange === item.val;
                    return (
                      <button
                        key={item.label}
                        type="button"
                        onClick={() => {
                          setReportDaysRange(item.val);
                          setCustomDaysInput('');
                        }}
                        className={`py-2 px-2 rounded-xl text-center border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-600 text-white border-emerald-600 font-bold shadow-xs'
                            : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {item.label}
                      </button>
                    );
                  })}
                </div>

                {/* Campo para días personalizados */}
                <div className="flex items-center gap-2 pt-1 border-t border-slate-100 text-xs">
                  <span className="text-slate-500 text-[11px]">Días personalizados:</span>
                  <input
                    type="number"
                    min="1"
                    max="365"
                    placeholder="Ej: 5"
                    value={customDaysInput}
                    onChange={(e) => {
                      const v = e.target.value;
                      setCustomDaysInput(v);
                      const n = parseInt(v, 10);
                      if (!isNaN(n) && n > 0) {
                        setReportDaysRange(n);
                      }
                    }}
                    className="w-20 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 text-center font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  {customDaysInput && (
                    <span className="text-[11px] text-emerald-600 font-medium">
                      Filtro activo ({customDaysInput} d.)
                    </span>
                  )}
                </div>
              </div>

              {/* Vista previa de lo que se incluirá en el informe */}
              <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200 space-y-2.5">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Resumen previo del informe a generar:
                </span>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-medium block">Ventas encontradas</span>
                    <span className="text-sm font-bold text-slate-800">{reportPreviewData.salesCount} ventas</span>
                  </div>

                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-[10px] text-slate-400 font-medium block">Unidades vendidas</span>
                    <span className="text-sm font-bold text-slate-800">{reportPreviewData.totalProductsQty} u.</span>
                  </div>
                </div>

                <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-emerald-800 font-bold uppercase block">Recaudación Total</span>
                    <span className="text-xs text-emerald-600">
                      Efectivo: ${reportPreviewData.totalCash.toFixed(2)} | Transf: ${reportPreviewData.totalTransfer.toFixed(2)}
                    </span>
                  </div>
                  <span className="text-base font-black text-emerald-700">
                    ${reportPreviewData.totalRevenue.toFixed(2)}
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 text-center leading-relaxed">
                Al pulsar <strong>"Crear informe"</strong>, se guardará en el registro permanente de informes y podrás desplegarlo para descargarlo o enviarlo.
              </p>
            </div>

            {/* Únicas opciones solicitadas: Cancelar o Crear informe */}
            <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsReportModalOpen(false)}
                className="flex-1 py-2.5 px-3 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-medium rounded-xl cursor-pointer text-xs transition-colors"
              >
                Cancelar
              </button>

              <button
                type="button"
                onClick={handleCreateReport}
                className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl active:scale-95 transition-all cursor-pointer shadow-xs text-xs"
              >
                Crear informe
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 8: AVISO ESPERANDO IMPLEMENTACIÓN (ENVÍO AL ADMINISTRADOR)          */}
      {/* ========================================================================= */}
      {isWaitingImplementationOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl p-5 text-xs text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-amber-50 text-amber-600 mx-auto flex items-center justify-center border border-amber-200">
              <Clock className="w-7 h-7 stroke-[2]" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Esperando implementación
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Como aún no hemos implementado las opciones online, la opción de enviar el informe al administrador se encuentra esperando implementación.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-left text-slate-600 text-[11px] space-y-1">
              <p className="font-semibold text-slate-800">
                ¿Qué puedes hacer mientras tanto?
              </p>
              <p className="text-slate-500 leading-normal">
                Puedes pulsar el botón <strong>Descargar</strong> para guardar el informe en la memoria local de tu dispositivo y compartirlo por WhatsApp, Bluetooth o imprimirlo.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setIsWaitingImplementationOpen(false)}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold cursor-pointer text-xs transition-colors shadow-xs"
            >
              Entendido
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
