export type PaymentMethod = 'efectivo' | 'transferencia';
export type AppTheme = 'claro' | 'oscuro' | 'verano' | 'invierno' | 'otono' | 'lavanda';

export interface Product {
  id: string;
  name: string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  category: string;
}

export interface CartItem {
  productId: string;
  productName: string;
  buyPrice: number;
  sellPrice: number;
  quantity: number;
  subtotal: number;
}

export interface ActiveSale {
  id: string;
  orderNumber: number;
  customerName?: string;
  paymentMethod: PaymentMethod;
  items: CartItem[];
  totalAmount: number;
  totalCost: number;
  createdAt: string;
}

export interface CompletedSale {
  id: string;
  orderNumber: number;
  customerName?: string;
  paymentMethod: PaymentMethod;
  items: CartItem[];
  totalAmount: number;
  totalCost: number;
  netProfit: number;
  completedAt: string;
  date: string; // YYYY-MM-DD
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  type: 'sale_completed' | 'sale_cancelled' | 'item_added' | 'backup_restored' | 'report_created';
  title: string;
  description: string;
  details?: {
    orderNumber?: number;
    customerName?: string;
    paymentMethod?: PaymentMethod;
    totalAmount?: number;
    itemsCount?: number;
    note?: string;
  };
}

export interface SalesReportProduct {
  productId: string;
  productName: string;
  sellPrice: number;
  quantity: number;
  subtotal: number;
}

export interface SalesReport {
  id: string;
  reportNumber: number;
  createdAt: string;
  dateLabel: string;
  daysRange: number | 'all';
  daysLabel: string;
  salesCount: number;
  totalProductsQty: number;
  totalRevenue: number;
  totalCash: number;
  totalTransfer: number;
  productsList: SalesReportProduct[];
}
